const dog_api = 'https://dog.ceo/api/'

