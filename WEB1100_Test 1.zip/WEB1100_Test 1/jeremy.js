const td = document.querySelectorAll('td')
const refresh = document.querySelector('.refresh')
const addPrice = document.querySelector('.addPrice')

class BitCoin{
    constructor(td, spots){
       this.td = td
       this.spots = spots
       this.getPrices()
    }

    setPrices(td, prices, spots){
        for(let i=0; i<spots.length; i++){
            td[i+1].textContent = prices[spots[i]].rate.toFixed(2)
        }
    }

    getPrices(){
        let prices
        $.ajax({
            url: "https://bitpay.com/api/rates",
            dataType:'json',
            success:(data)=>{
                console.log(data)
                this.prices = data
                this.setPrices(this.td, this.prices, this.spots)
            },
            error:(error)=>{
                console.log("There was an error getting from the API")
            }
        })  
    }
    refresh(){
        this.getPrices()
    }
}

const bit = new BitCoin(td, [0,2,3,4,5,6])

refresh.addEventListener('click', function(e){
    bit.refresh()
})

addPrice.addEventListener('click', function(e){
    const info = window.prompt(`Which currency would you like?`).toUpperCase()
    if(info){
    const tr = document.querySelectorAll('tr')
    for(let i=0; i<bit.prices.length; i++){
        if(bit.prices[i].code === info.toUpperCase()) {
            tr[0].innerHTML += `<th>BTC/${info}</th>`
            tr[1].innerHTML += `<td></td>`
            bit.spots.push(i)
            bit.td = document.querySelectorAll('td')
            bit.getPrices()
            break
        } 
    }

    }
})